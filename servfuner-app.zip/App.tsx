
import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function App() {
  const [telaAtual, setTelaAtual] = useState('painel');
  const [ocorrencias, setOcorrencias] = useState([]);
  const [jazigos, setJazigos] = useState([]);
  const [clientes, setClientes] = useState([]);

  const [novaOcorrencia, setNovaOcorrencia] = useState({
    nome: '',
    dataHora: '',
    velorio: '',
    sepultamento: '',
    responsavel: '',
    observacoes: '',
    jazigoId: ''
  });

  const [novoJazigo, setNovoJazigo] = useState({
    identificacao: '',
    localizacao: '',
    capacidade: '',
    observacoes: ''
  });

  const [novoCliente, setNovoCliente] = useState({
    nome: '',
    telefone: '',
    email: '',
    endereco: '',
    observacoes: ''
  });

  useEffect(() => {
    const armazenadas = localStorage.getItem('ocorrencias');
    if (armazenadas) setOcorrencias(JSON.parse(armazenadas));

    const jazigosArmazenados = localStorage.getItem('jazigos');
    if (jazigosArmazenados) setJazigos(JSON.parse(jazigosArmazenados));

    const clientesArmazenados = localStorage.getItem('clientes');
    if (clientesArmazenados) setClientes(JSON.parse(clientesArmazenados));
  }, []);

  useEffect(() => {
    localStorage.setItem('ocorrencias', JSON.stringify(ocorrencias));
  }, [ocorrencias]);

  useEffect(() => {
    localStorage.setItem('jazigos', JSON.stringify(jazigos));
  }, [jazigos]);

  useEffect(() => {
    localStorage.setItem('clientes', JSON.stringify(clientes));
  }, [clientes]);

  const salvarOcorrencia = (e) => {
    e.preventDefault();
    setOcorrencias([...ocorrencias, novaOcorrencia]);
    setNovaOcorrencia({ nome: '', dataHora: '', velorio: '', sepultamento: '', responsavel: '', observacoes: '', jazigoId: '' });
    alert('Ocorrência salva com sucesso!');
  };

  const salvarJazigo = (e) => {
    e.preventDefault();
    setJazigos([...jazigos, novoJazigo]);
    alert(`Jazigo "${novoJazigo.identificacao}" salvo com sucesso!`);
    setNovoJazigo({ identificacao: '', localizacao: '', capacidade: '', observacoes: '' });
  };

  const salvarCliente = (e) => {
    e.preventDefault();
    setClientes([...clientes, novoCliente]);
    alert(`Cliente "${novoCliente.nome}" salvo com sucesso!`);
    setNovoCliente({ nome: '', telefone: '', email: '', endereco: '', observacoes: '' });
  };

  const excluirCliente = (index) => {
    const novaLista = [...clientes];
    novaLista.splice(index, 1);
    setClientes(novaLista);
  };

  const excluirJazigo = (index) => {
    const novaLista = [...jazigos];
    novaLista.splice(index, 1);
    setJazigos(novaLista);
  };

  const excluirOcorrencia = (index) => {
    const novaLista = [...ocorrencias];
    novaLista.splice(index, 1);
    setOcorrencias(novaLista);
  };

  const renderizarTela = () => {
    switch (telaAtual) {
      case 'novaOcorrencia':
        return (
          <form onSubmit={salvarOcorrencia} className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-800">Nova Ocorrência</h2>
            <input type="text" placeholder="Nome" value={novaOcorrencia.nome}
              onChange={(e) => setNovaOcorrencia({ ...novaOcorrencia, nome: e.target.value })}
              className="w-full p-2 border rounded" required />
            <input type="datetime-local" placeholder="Data e Hora" value={novaOcorrencia.dataHora}
              onChange={(e) => setNovaOcorrencia({ ...novaOcorrencia, dataHora: e.target.value })}
              className="w-full p-2 border rounded" required />
            <input type="text" placeholder="Velório" value={novaOcorrencia.velorio}
              onChange={(e) => setNovaOcorrencia({ ...novaOcorrencia, velorio: e.target.value })}
              className="w-full p-2 border rounded" />
            <input type="text" placeholder="Sepultamento" value={novaOcorrencia.sepultamento}
              onChange={(e) => setNovaOcorrencia({ ...novaOcorrencia, sepultamento: e.target.value })}
              className="w-full p-2 border rounded" />
            <input type="text" placeholder="Responsável" value={novaOcorrencia.responsavel}
              onChange={(e) => setNovaOcorrencia({ ...novaOcorrencia, responsavel: e.target.value })}
              className="w-full p-2 border rounded" />
            <textarea placeholder="Observações" value={novaOcorrencia.observacoes}
              onChange={(e) => setNovaOcorrencia({ ...novaOcorrencia, observacoes: e.target.value })}
              className="w-full p-2 border rounded" />
            <select value={novaOcorrencia.jazigoId}
              onChange={(e) => setNovaOcorrencia({ ...novaOcorrencia, jazigoId: e.target.value })}
              className="w-full p-2 border rounded">
              <option value="">Selecione um Jazigo</option>
              {jazigos.map((jazigo, index) => (
                <option key={index} value={jazigo.identificacao}>
                  {jazigo.identificacao} - {jazigo.localizacao}
                </option>
              ))}
            </select>
            <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
              Salvar Ocorrência
            </button>
          </form>
        );
      case 'painel':
        return <p className="text-gray-700 mt-6">Bem-vindo ao painel do sistema <strong>ServFuner</strong>.</p>;
      case 'jazigos':
        return <p className="text-gray-600">Tela de cadastro e listagem de jazigos (em desenvolvimento).</p>;
      case 'cadastroCliente':
        return <p className="text-gray-600">Tela de cadastro de cliente (em desenvolvimento).</p>;
      case 'ocorrencias':
        return <p className="text-gray-600">Tela de ocorrências (em desenvolvimento).</p>;
      case 'relatorios':
        return <p className="text-gray-600">Tela de relatórios (em desenvolvimento).</p>;
      default:
        return null;
    }
  };

  const BotaoMenu = ({ texto, valor }) => (
    <button
      onClick={() => setTelaAtual(valor)}
      className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
    >
      {texto}
    </button>
  );

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center p-8">
      <h1 className="text-4xl font-bold text-gray-800 mb-6">ServFuner - Sistema Funerário</h1>
      <div className="flex flex-wrap gap-4 mb-8">
        <BotaoMenu texto="Painel" valor="painel" />
        <BotaoMenu texto="Nova Ocorrência" valor="novaOcorrencia" />
        <BotaoMenu texto="Ocorrências" valor="ocorrencias" />
        <BotaoMenu texto="Jazigos" valor="jazigos" />
        <BotaoMenu texto="Relatórios" valor="relatorios" />
        <BotaoMenu texto="Cadastro de Cliente" valor="cadastroCliente" />
      </div>
      <div className="w-full max-w-4xl bg-white shadow-md rounded-xl p-6">
        {renderizarTela()}
      </div>
    </div>
  );
}
