# ServFuner
Sistema de gestão funerária em React + Vite.