import React from 'react';

function App() {
  return (
    <div>
      <h1>ServFuner</h1>
      <p>Bem-vindo ao sistema de gestão funerária.</p>
    </div>
  );
}

export default App;
